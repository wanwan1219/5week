/**
 * Created by 123 on 2017/8/16.
 */

(function(){
    var index=0;
    var k=0;
    var len=$(".banner ul li").length,
        prev=$(".banner .click .prev"),
        next=$(".banner .click .next"),
        ban=$(".banner"),
        dot=$(".banner .click .center-center img");
//加载头部
    $(function(){
        $("#header").load("header.html")
    });
//点点点击
    dot.click(function(){
        index=$(this).index();
        comm();
    });
//左箭头点击
    prev.hover(function(){
        $(this).find("img").attr("src","images/prev_jiantou_hover.png");
        next.find("img").attr("src","images/next_jiantou.png");
    }).click(function(){
        index--;
        if(index<0){
            index=len-1;
        }
        comm();
    });
//定义公用的两句代码 换图片及点点的颜色
    function comm(){
        $(".banner ul li").fadeOut(0).eq(index).fadeIn();
        dot.attr("src","images/next&prev_others.png").eq(index).attr("src","images/next&prev_now.png")
    }
//点击右箭头
    next.hover(function(){
        $(this).find("img").attr("src","images/next_jiantou_hover.png");
        prev.find("img").attr("src","images/prev_jiantou.png");
    }).click(function(){
        right();
    });
//定义右点击及自动播放的右向通用
    function right(){
        index++;
        if(index>len-1){
            index=0;
        }
        comm();
    }
//定时器
    var timer=setInterval(right,2000);
    ban.hover(function(){
        clearInterval(timer)
    },function(){
        timer=setInterval(right,2000);
    });
})();



//main1
(function(){
    var line=$(".main1 .main1-bot .main1-bot-lt .line"),
        content=$(".main1 .main1-bot-rt .content1"),
        len=$(".main1 .main1-bot-rt .content1").length,
        img=$(".main1 .main1-bot-rt .content1 .img1"),
        rt=$(".main1 .main1-bot-rt .content1 .content-rt"),
        index= 0,
        m=0,
        prev=$(".main1 .main1-bot .main1-bot-rt .content-main3 .prev"),
        next=$(".main1 .main1-bot .main1-bot-rt .content-main3 .next");
//main1左侧
    line.click(function(){
        m=index;
        index=$(this).index();
        content.hide().eq(index).show();
        $(this).addClass("now").siblings().removeClass("now");
        if(m<index){
          nn()
        }else{
            mm()
        }
    });
    function mm(){
        img.removeClass("animated fadeInRight").eq(index).addClass("animated fadeInLeft");
        rt.removeClass("animated fadeInRight").eq(index).addClass("animated fadeInLeft");
    }
    function nn(){
        img.removeClass("animated fadeInLeft").eq(index).addClass("animated fadeInRight");
        rt.removeClass("animated fadeInLeft").eq(index).addClass("animated fadeInRight");
    }
//main1箭头
    prev.click(function(){
        index--;
        if(index<0){
            index=len-1;
        }
        content.hide().eq(index).show();
        mm();
        line.removeClass("now").eq(index).addClass("now");
           });
    next.click(function(){
        index++;
        if(index>len-1){
            index=0;
        }
        content.hide().eq(index).show();
        nn();
        line.removeClass("now").eq(index).addClass("now");
    })
})();



//main3开始
(function(){
    var icon=$(".main3 .main3-bot ul li .icon"),
        ol=$(".main3 .main3-bot ul li ol");

    $(".main3 .main3-bot ul li .centering").hover(function(){
        $(this).addClass("animated tada")
    },function(){
        $(this).removeClass("animated tada")
    });
    icon.hover(function(){
        $(this).addClass("animated tada")
    },function(){
        $(this).removeClass("animated tada")
    });
    icon.click(function(){
        if($(this).hasClass("icon1")){
            $(this).removeClass("icon1")
        }else{
            $(this).addClass("icon1");
        }
        $(this).parent().parent().siblings().find("ol").hide();
        $(this).parent().siblings().slideToggle();
        $(this).parent().parent().siblings().find(".box").find(".icon").removeClass("icon1");
    })
})();